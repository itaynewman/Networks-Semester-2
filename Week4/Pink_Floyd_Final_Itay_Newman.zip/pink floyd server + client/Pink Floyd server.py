import socket
import data

SERVER_IP = '127.0.0.1'
SERVER_PORT = 170

MENU = """
Commands:
1. Request Albums
2. Request Songs in Album
3. Request Song Length
4. Request Song Lyrics
5. Request Album for Song
6. Search Song by Name
7. Search Song by Lyrics
8. Get Most Common Words
9. Get Albums Sorted by Length
10. Exit
"""

# Parse the data file
file_path = "C:\\Users\\Cyber_User\\Downloads\\Pink_Floyd_DB.txt"
albums, songs = data.parse_data(file_path)


def handle_request(request):
    """
    Handle the request from the client
    :param request:
    :return:
    """
    parts = request.split('&')
    command = parts[0]

    if command == '1':
        return data.get_albums(albums, songs)
    elif command == '2':
        album_name = parts[1]
        return data.get_songs_in_album(albums, songs, album_name)
    elif command == '3':
        song_name = parts[1]
        return data.get_song_length(albums, songs, song_name)
    elif command == '4':
        song_name = parts[1]
        return data.get_song_lyrics(albums, songs, song_name)
    elif command == '5':
        song_name = parts[1]
        return data.get_album_for_song(albums, songs, song_name)
    elif command == '6':
        search_text = parts[1]
        return data.search_song_by_name(albums, songs, search_text)
    elif command == '7':
        search_text = parts[1]
        return data.search_song_by_lyrics(albums, songs, search_text)
    elif command == '8':
        return data.get_most_common_words(albums, songs)
    elif command == '9':
        return data.get_albums_sorted_by_length(albums, songs)
    elif command == '10':
        return "Thank you for using the Pink Floyd Server! Bye Bye!"
    else:
        return "The requested item was not found."


def handle_client(client_socket):
    """
    Handle the request from the client
    :param client_socket:
    :return:
    """
    try:
        welcome_message = "Welcome to the Pink Floyd server!"
        client_socket.send(welcome_message.encode())

        while True:
            client_socket.send(MENU.encode())  # Send the menu to the client
            request = client_socket.recv(1024).decode()
            if not request:
                break

            response = handle_request(request)
            client_socket.send(response.encode())

            if request.startswith('10'):
                break
    except (socket.error, ConnectionResetError) as e:
        print(f"Connection error: {e}")
    finally:
        client_socket.close()


def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((SERVER_IP, SERVER_PORT))
    server.listen(5)
    print(f"Server listening on {SERVER_IP}:{SERVER_PORT}")

    while True:
        try:
            client_socket, addr = server.accept()
            print(f"Accepted connection from {addr}")
            handle_client(client_socket)
        except Exception as e:
            print(f"Error accepting connection: {e}")


if __name__ == "__main__":
    main()
